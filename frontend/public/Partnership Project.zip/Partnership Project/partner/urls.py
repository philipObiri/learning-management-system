from django.urls import path 
from . import views 

urlpatterns = [
    path("", views.index, name="home"),
    path("partner/", views.initiate_partnership, name="partner"),
    path("dashboard/", views.dashboard, name="dashboard")
]
