from django.contrib import admin
from .models import Payment

# Register your models here.

admin.site.register(Payment)
