from django.shortcuts import render, redirect
from .models import Partnership
from .form import PartnershipForm
from payment.models import Payment
from django.conf import settings


# Create your views here.
def index(request):
    return render(request, "homepage.html")


def initiate_partnership(request):
    if request.method == "POST":
        form = PartnershipForm(request.POST)

        if form.is_valid():
            new_partnership = form.save()  # Correct variable name
            new_payment = Payment.objects.create(
                amount=new_partnership.partnership_amount,
                email=request.user.email,
                user=request.user,
            )

            # Save the payment object
            new_payment.save()

            pk = settings.PAYSTACK_PUBLIC_KEY
            context = {
                "total_amount": new_payment.amount,
                "payment": new_payment,
                "paystack_public_key": pk,
                "amount_value": new_payment.amount_value(),
            }
            request.session["partnership_id"] = new_partnership.id
            return render(request, "payment/make_payment.html", context)
        else:
            messages.warning(request, "Error, something went wrong")
            return redirect("home")

    else:
        form = PartnershipForm()
        context = {"form": form}
        return render(request, "partner/partnership-form.html", context)


def dashboard(request):
    payments = Payment.objects.all().filter(user=request.user)
    return render(request, "account/dashboard.html", {"payments": payments})
