from django import forms
from .models import Partnership

class PartnershipForm(forms.ModelForm):
    class Meta:
        model = Partnership
        fields = ["full_name", "partnership_amount", "phone_number","location"]