from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Partnership(models.Model):
    full_name = models.CharField(max_length=100)
    partnership_amount = models.DecimalField(decimal_places=3, max_digits=12)
    phone_number = models.CharField(max_length=100)
    location= models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)
    # let's say a Partner makes payment . We would like to verify  the payment
    is_verified = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.full_name} partnered an amount of {self.partnership_amount}GHS"


