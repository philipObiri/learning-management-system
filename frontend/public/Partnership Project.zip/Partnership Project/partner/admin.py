from django.contrib import admin
from .models import Partnership

# Register your models here.
admin.site.register(Partnership)
